#ifndef MENUS_H
#define MENUS_H

Tela tela_menu_principal();
Tela tela_resolucao_menu_principal(int *tamanho_bloco);
Tela tela_menu();

#endif
